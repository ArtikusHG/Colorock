//
//  ViewController.m
//  ;
//
//  Created by ArtikusHG on 8/5/17.
//  Copyright © 2017 ArtikusHG. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
- (IBAction)rock:(id)sender {
    int r;
    r = arc4random() % 7;
    if (r == 6) { // dope
        self.view.backgroundColor = [UIColor colorWithRed:0.45 green:0.64 blue:0.96 alpha:1.0];
    } else if (r == 5) { // dope
        self.view.backgroundColor = [UIColor orangeColor];
    } else if (r == 4) { // dope
        self.view.backgroundColor = [UIColor colorWithRed:0.87 green:0.40 blue:0.40 alpha:1.0];
    } else if (r == 3) { // dope
        self.view.backgroundColor = [UIColor colorWithRed:0.80 green:0.47 blue:0.47 alpha:1.0];
    } else if (r == 2) { // dope
        self.view.backgroundColor = [UIColor colorWithRed:0.82 green:0.73 blue:0.45 alpha:1.0];
    } else if (r == 1) { // dope
        self.view.backgroundColor = [UIColor colorWithRed:0.48 green:0.63 blue:0.46 alpha:1.0];
    } else { // not dope
        self.view.backgroundColor = [UIColor colorWithRed:0.48 green:0.44 blue:0.44 alpha:1.0];
    }
    NSLog(@"Current color: %d", r);
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"Application launched");
    int r;
    r = arc4random() % 7;
    if (r == 6) { // dope
        self.view.backgroundColor = [UIColor colorWithRed:0.45 green:0.64 blue:0.96 alpha:1.0];
    } else if (r == 5) { // dope
        self.view.backgroundColor = [UIColor orangeColor];
    } else if (r == 4) { // dope
        self.view.backgroundColor = [UIColor colorWithRed:0.87 green:0.40 blue:0.40 alpha:1.0];
    } else if (r == 3) { // dope
        self.view.backgroundColor = [UIColor colorWithRed:0.80 green:0.47 blue:0.47 alpha:1.0];
    } else if (r == 2) { // dope
        self.view.backgroundColor = [UIColor colorWithRed:0.82 green:0.73 blue:0.45 alpha:1.0];
    } else if (r == 1) { // dope
        self.view.backgroundColor = [UIColor colorWithRed:0.48 green:0.63 blue:0.46 alpha:1.0];
    } else { // not dope
        self.view.backgroundColor = [UIColor colorWithRed:0.48 green:0.44 blue:0.44 alpha:1.0];
    }
    NSLog(@"Current color: %d", r);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
