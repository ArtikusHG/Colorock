//
//  AppDelegate.h
//  Colorock
//
//  Created by ArtikusHG on 8/5/17.
//  Copyright © 2017 ArtikusHG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

